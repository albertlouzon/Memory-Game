var startButton = document.getElementById("startButton").addEventListener("click", function () { startInit() });
var theme1 = document.getElementById("art").addEventListener("click", function () { themeChangerArt() });
var theme2 = document.getElementById("pokemon").addEventListener("click", function () { themeChangerPokemon() });
var userTheme = 1; // default theme is Pokemon.

function themeChangerPokemon() {
    userTheme = 1;
};

function themeChangerArt() {
    userTheme = 2;

};

function startInit() {
    var memoGame = {
        images: [],
        numOfGuesses: 0,
        difficultyLvl: 0,
        numOfimg: 0,
        imgClass: [],
        scoreBox: 0,
        difficulty: function () {       //Display the difficulty buttons. 
            document.getElementById("startButton").style.display = "none";
            document.getElementById("art").style.display = "none";
            document.getElementById("pokemon").style.display = "none";
            document.getElementById("easyButton").style.display = "block";
            document.getElementById("mediumButton").style.display = "block";
            document.getElementById("hardButton").style.display = "block";
            var easy = document.getElementById("easyButton").addEventListener("click", function () { // easy/medium/hard :set the number of images. Adjust the array containing the pair values. Adjust style.
                memoGame.numOfImg = +12;
                memoGame.images = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6];
                document.getElementById("buttonContainer").style.display = "none";
                memoGame.startGame();
            });
            var medium = document.getElementById("mediumButton").addEventListener("click", function () {
                document.getElementById("buttonContainer").style.display = "none";
                memoGame.numOfImg = +18;
                memoGame.images = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9];

                memoGame.startGame();
            });
            var hard = document.getElementById("hardButton").addEventListener("click", function () {
                document.getElementById("buttonContainer").style.display = "none";
                memoGame.numOfImg = +24;
                memoGame.images = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12];
                memoGame.startGame();
            });

        },

        startGame: function () {
            for (i = 0; i < memoGame.numOfImg; i++) {   // create as many "image containers" as the difficulty demands (12, 18 or 24)
                var imgDiv = document.createElement("div");
                document.getElementById("imgContainer").appendChild(imgDiv);
                imgDiv.className = "image hiddenPair clickable";
                if (memoGame.images.length == 18) {
                    document.getElementsByClassName("image")[i].style.width = "15vh" //css adjustements because of the increasing number of images.
                    document.getElementsByClassName("image")[i].style.margin = "3% 3%";
                }
                else if (memoGame.images.length == 24) {
                    document.getElementsByClassName("image")[i].style.width = "15vh"
                    document.getElementsByClassName("image")[i].style.height = "15vh"
                    document.getElementsByClassName("image")[i].style.margin = "2% 3%";
                }
            }
            if (userTheme == 1) {           // Theme changer
                var audioPok = new Audio('pokemonGameSound.mp3');
                audioPok.play();
                document.getElementById("imgContainer").style.backgroundImage = "url('images/backGrd2.png')"
            }
            else if (userTheme == 2) {
                var audioArt = new Audio('zenSong.mp3');
                audioArt.play();
                document.getElementById("imgContainer").style.backgroundImage = "url('images/backGrdArt.png')"
                for (var i = 0; i < memoGame.images.length; i++) {
                    document.getElementsByClassName("image")[i].style.borderRadius = "0px";
                    document.getElementsByClassName("image")[i].style.border = "1px white solid";
                    document.getElementsByClassName("image")[i].style.backgroundColor = "rgba(0, 0, 0, 0.8)";

                }
            }
            document.getElementById("scoreBoxResetGame").style.display = "flex";
            memoGame.scoreBox = document.createElement("span");
            document.getElementById("bigBox").appendChild(memoGame.scoreBox);
            memoGame.scoreBox.className = "scoreBox";
            memoGame.scoreBox.innerHTML = "Wrong guesses : 0"

            memoGame.shuffle();

        },
        shuffle: function () {  // Takes the memoGame.images array and return a random array. Then assign the same value to each pair. 
            var randomNum = 0;
            var randomArray = 0;

            for (var i = 1; i < memoGame.images.length; i++) {
                randomNum = Math.floor((Math.random() * i));
                randomArray = memoGame.images[i];
                memoGame.images[i] = memoGame.images[randomNum];
                memoGame.images[randomNum] = randomArray;

                $(".image").each(function (i) { 
                    $(this).attr("value", memoGame.images[i]); 
                });

            };
            console.log(memoGame.images); //we console log the randomized array so that we can cheat during testing stages.
            memoGame.clickEvent();
        },

        clickEvent: function () {           //Display different backgroundImages according to the "value" attribute and to the theme chosen. (Cf shuffle();)
            memoGame.imgClass = document.getElementsByClassName("clickable");
            for (var i = 0; i <= memoGame.imgClass.length; i++) {
                document.getElementsByClassName("clickable")[i].addEventListener("click", function (e) {
                    var x = e.target
                    x.classList.add("userChoice")           
                    var getAttr = x.getAttribute("value");
                    if (userTheme == 1) {

                        if (getAttr == 1) {
                            x.classList.add("img-1");
                        }
                        if (getAttr == 2) {
                            x.classList.add("img-2");
                        }
                        if (getAttr == 3) {
                            x.classList.add("img-3");
                        }
                        if (getAttr == 4) {
                            x.classList.add("img-4");
                        }
                        if (getAttr == 5) {
                            x.classList.add("img-5");
                        } if (getAttr == 6) {
                            x.classList.add("img-6");
                        } if (getAttr == 7) {
                            x.classList.add("img-7");
                        } if (getAttr == 8) {
                            x.classList.add("img-8");
                        } if (getAttr == 9) {
                            x.classList.add("img-9");
                        } if (getAttr == 10) {
                            x.classList.add("img-10");
                        } if (getAttr == 11) {
                            x.classList.add("img-11");
                        } if (getAttr == 12) {
                            x.classList.add("img-12");
                        }
                    } else if (userTheme == 2) {
                        if (getAttr == 1) {
                            x.classList.add("img_1");
                        }
                        if (getAttr == 2) {
                            x.classList.add("img_2");
                        }
                        if (getAttr == 3) {
                            x.classList.add("img_3");
                        }
                        if (getAttr == 4) {
                            x.classList.add("img_4");
                        }
                        if (getAttr == 5) {
                            x.classList.add("img_5");
                        } if (getAttr == 6) {
                            x.classList.add("img_6");
                        } if (getAttr == 7) {
                            x.classList.add("img_7");
                        } if (getAttr == 8) {
                            x.classList.add("img_8");
                        } if (getAttr == 9) {
                            x.classList.add("img_9");
                        } if (getAttr == 10) {
                            x.classList.add("img_10");
                        } if (getAttr == 11) {
                            x.classList.add("img_11");
                        } if (getAttr == 12) {
                            x.classList.add("img_12");
                        }
                    }



                    memoGame.checkIfPair();
                });
            }


        },


        checkIfPair: function () {  //when the users clicked on 2 different images, we check if his first pick has the same "value" attribute than his last pick. 
            if (document.getElementsByClassName("userChoice").length == 2) {
                var allImages = [];

                var userFirstChoice = document.getElementsByClassName("userChoice")[0];
                var userLastChoice = document.getElementsByClassName("userChoice")[1];
                if (userFirstChoice.getAttribute("value") == userLastChoice.getAttribute("value")) { // if the user gets a pair, the cards are locked and the user can no longer click on it
                    var isPairSound = new Audio('taDa.mp3');
                    isPairSound.play();
                    userFirstChoice.classList.add("pairs");
                    userFirstChoice.classList.remove("hiddenPair");
                    userLastChoice.classList.add("pairs");
                    userLastChoice.classList.remove("hiddenPair");
                    userLastChoice.classList.remove("clickable");
                    userFirstChoice.classList.remove("clickable");
                    userFirstChoice.classList.remove("userChoice");
                    userLastChoice.classList.remove("userChoice"); // reset userChoice to 0

                }
                else {
                    memoGame.numOfGuesses = +memoGame.numOfGuesses + +1;  //if no pair, we remove the class that was displaying the image and we add 1 to the number of wrong guesses
                    for (var i = 0; i < memoGame.images.length; i++) {
                        allImages.push(document.getElementsByClassName("image")[i]);
                        allImages[i].classList.add("temporaryOff");
                    }
                    setTimeout(function () {
                        var isntPair = new Audio('wrongSong.mp3');
                        isntPair.play();
                        userFirstChoice.classList.remove("userChoice"); //reset uuserChoice to 0
                        userLastChoice.classList.remove("userChoice");
                        for (var i = 0; i < memoGame.images.length; i++) {
                            userFirstChoice.classList.remove("img-" + i);
                            userLastChoice.classList.remove("img-" + i);
                            userFirstChoice.classList.remove("img_" + i);
                            userLastChoice.classList.remove("img_" + i);
                            allImages[i].classList.remove("temporaryOff");
                            memoGame.scoreBox.innerHTML = "Wrong guesses : " + memoGame.numOfGuesses;
                        }
                    }, 1000);

                }
            }

            memoGame.checkIfWon();
        },


        checkIfWon: function () {
            var hiddenPair = document.getElementsByClassName("hiddenPair").length;
            if (hiddenPair == 0) {          //All the pairs are found when there is no more pair to be found.
                var isWinSound = new Audio('victorySound.mp3');
                isWinSound.play();
                if (memoGame.numOfGuesses <= 5) { //different messages according to the number of wrong guesses
                    document.getElementById("finalBox").innerHTML = "WOW very impressive !!! You did it with only  " + memoGame.numOfGuesses + " wrong guesses !";
                    document.getElementById("finalBox").style.display = "flex";
                } else if (memoGame.numOfGuesses <= 15) {
                    document.getElementById("finalBox").innerHTML = "WELL DONE ! You won with " + memoGame.numOfGuesses + " wrong guesses ! But I know you can do better.....come on !!!";
                    document.getElementById("finalBox").style.display = "flex";
                } else {
                    document.getElementById("finalBox").innerHTML = "Ah....well you made it to the end. Dont be ashamed of your " + memoGame.numOfGuesses + " wrong guesses...it happens to the best of us";
                    document.getElementById("finalBox").style.display = "flex";
                }
            }
        },

    };
    memoGame.difficulty();
};